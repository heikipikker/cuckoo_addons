// sample_con.c - default CUI binary for INetSim
//
// (c)2007,2008 Matthias Eckert, Thomas Hungenberg
//
// Compile with: cl /nologo sample_con.c

#include <windows.h>



void main()
{
    printf("This is the INetSim default binary\n");
    Sleep(10000);
}
